require 'spec_helper'
require 'Spreadsheet'

module Feature
	module Function
		def visitPage(page)
			visit "#{page}"
		end
		def searchFunction(page,path,key)
			visit "#{page}"
			fill_in "#{path}", with: key
			sleep(1)
			find("input##{path}").native.send_key(:enter)
			sleep(2)
		end
		def writeExcelFile(page,key,path,namePath,pricePath,linkPath,size,sheet)
			doc = parseHTML
			results = find_all(:xpath,"#{path}")
			results.map { |e| 
				iname = e.find(:xpath,"#{namePath}").text
				if iname.include?(key)
					puts 'Search resuts is true'
				else
					puts 'Search results is failed'
				end
				if e.has_xpath?("#{pricePath}")
					iprice = e.find(:xpath,"#{pricePath}").text
					iprice = iprice.gsub('/^[0-9.]/','')
				else
					iprice = 'N/A'
				end
				i = results.index(e).to_i
				index1 = size + i + 1
				link = doc.css("#{linkPath}")[i]['href']
				ilink = "#{page}#{link}"
				sheet.row(index1).push(page, iname,iprice,ilink)
			}
			return results.size
		end
		def createExcelFile
			book = Spreadsheet::Workbook.new 
			sheet = book.create_worksheet(name: 'Output')
			sheet.row(0).push('Website', 'Name','Price','URL')
			return sheet, book
		end
		def save(book)
			book.write 'Output.xls'
		end
		def parseHTML
			url = page.current_url
			doc = Nokogiri::HTML(open(url))
			return doc
		end
	end
end