class Page
	def self.fptshop
		'https://fptshop.com.vn'
	end
	def self.thegioididong
		'https://www.thegioididong.com'
	end
end