require 'webdrivers'
require 'selenium-webdriver'
require 'capybara/rspec'
require 'capybara-screenshot/rspec'
require 'pry'

Webdrivers.install_dir = 'D:\Auto\Host\webdrivers'
# RSPEC_ROOT = 'D:/Data/house_picture'
# Capybara.register_driver :chrome do |app|
#   if ENV['SELENIUM_URL'].nil?
#     Capybara::Selenium::Driver.new(app, browser: :chrome)
#   else
#     Capybara::Selenium::Driver.new(
#       app,
#       browser: :chrome,
#       url: ENV["SELENIUM_URL"]
#     )
#   end
# end
Capybara.javascript_driver = :chrome
Capybara.register_driver :selenium do |app|
  if ENV['SELENIUM_URL'].nil?
    Capybara::Selenium::Driver.new(app, browser: :firefox)
  else
    Capybara::Selenium::Driver.new(
      app,
      browser: :firefox,
      url: ENV["SELENIUM_URL"]
    )
  end
end
Capybara.javascript_driver = :firefox
Capybara::Screenshot.autosave_on_failure = true
Capybara.save_path = 'screenshot'

Capybara.configure do |config|
  config.default_max_wait_time = 10 # seconds
  Capybara.run_server = false
  config.default_driver = :selenium
end

RSpec.configure do |config|
  config.before(:each, type: :feature) do
    Capybara.current_session.driver.browser.manage.window.maximize
  end
end