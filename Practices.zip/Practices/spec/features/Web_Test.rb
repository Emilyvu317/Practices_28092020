require 'spec_helper'
require 'Nokogiri'
require 'open-uri'
require_relative '../helpers/page'
require_relative '../helpers/child_function'

RSpec.configure do |config|
  config.include Feature::Function, type: :feature
end

feature 'Get Data & export to file ' do
	scenario 'Get Data' do
		fpage = Page.fptshop
		tpage = Page.thegioididong
		key = 'iPhone 11'
		fkey = 'key'
		tkey = 'search-keyword'
		sleep(1)
		sheet, book = createExcelFile
		searchFunction(fpage,fkey,key)
		fpath = '//div/div/div/div/div[2]/div[@class="fs-lpitem"]'
		fnamePath = './a/h3'
		fpricePath = './a/p[@class="fs-icpri"]'
		flinkPath = 'div.fs-lpitem a'
		fsize = 0
		tsize = writeExcelFile(fpage,key,fpath,fnamePath,fpricePath,flinkPath,fsize,sheet)
		searchFunction(tpage,tkey,key)
		tpath = '//aside/ul[2]/li[@class="cat42 "]'
		tnamePath = './a/h3'
		tpricePath = 'a/div[@class="price"]/strong'
		tlinkPath = 'li.cat42 a'
		writeExcelFile(tpage,key,tpath,tnamePath,tpricePath,tlinkPath,tsize,sheet)
		save(book)
	end
end