# automation-tests

## Requirements

- ruby 2.6 with bundler
- Firefox

## Installation

- bundle install --path gems

## Test Execution

- bundle exec rspec

## References

- [Capybara](https://github.com/teamcapybara/capybara)
